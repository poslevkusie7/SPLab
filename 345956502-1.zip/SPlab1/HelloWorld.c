#include <stdio.h>

int main () {
    printf("HelloWOrld!\n");
    return 0;
}